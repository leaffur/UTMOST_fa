__author__ = 'heroico'

IMPUTE = "IMPUTE"
PrediXcan = "PrediXcan"

DatabaseFile = "DatabaseFile"
FlatFile = "FlatFile"
